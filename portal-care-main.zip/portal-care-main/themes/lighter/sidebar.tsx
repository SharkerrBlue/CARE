export default function LighThemeSidebar() {
  return <div>Sidebar</div>;
}
