export interface StatsProps {
  datasetCount: number;
  orgCount: number;
  groupCount: number;
}
